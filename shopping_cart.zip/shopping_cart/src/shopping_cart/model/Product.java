package shopping_cart.model;

public class Product
{
	private String prodId;
	private String prodName;
	
	private double  prodPrice;
	private int prodQty;
	private double prodAmt;
	
	public Product(String pId, String prodName, double pprice,int prodQty) {
		super();
		this.prodId = pId;
		this.prodName = prodName;
		this.prodPrice = pprice;
		this.prodQty= prodQty;
	}
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	public int getProdQty() {
		return prodQty;
	}
	public void setProdQty(int prodQty) {
		this.prodQty = prodQty;
	}
	public double getProdAmt() {
		return prodAmt;
	}
	public void setProdAmt(double prodAmt) {
		this.prodAmt = prodAmt;
	}
	
}
