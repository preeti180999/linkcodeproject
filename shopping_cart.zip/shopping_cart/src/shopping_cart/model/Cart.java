package shopping_cart.model;
public class Cart {

    private String pID;
    private String pName;
    private double pPrice;
    private int quantity;


    public Cart(String prodId, String prodName, double d, int quantity) {
    	 this.pID = pID;
         this.pName = pName;
         this.pPrice = d;
         this.quantity = quantity;
		// TODO Auto-generated constructor stub
	}


	public String getpID() {
        return pID;
    }

    public void setpID(String pID) {
        this.pID = pID;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public double getpPrice() {
        return pPrice;
    }

    public void setpPrice(int pPrice) {
        this.pPrice = pPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    

   
    

}