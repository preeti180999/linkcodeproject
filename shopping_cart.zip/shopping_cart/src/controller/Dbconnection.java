package controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dbconnection {
	 private static String serverName = "localhost";
	    private static String dbName = "cart";
	    private static String portNumber = "3306";
	    private static String userID = "root";
	    private static String password = "root";

	  public static Connection getConnection()throws Exception {
		  String url="jdbc:mysql://127.0.0.1:3306/mydatabase?serverTimezone=UTC";
		  Class.forName("com.mysql.cj.jdbc.Driver"); 	
		return (DriverManager.getConnection(url, userID, password));
		  
	  }
}
