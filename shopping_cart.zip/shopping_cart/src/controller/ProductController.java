package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import shopping_cart.model.Cart;
import shopping_cart.model.Product;
@WebServlet("/ProductController")
public class ProductController extends HttpServlet
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		System.out.println("hiiiiiiiiiiiiiiiiiiiiii");

		HttpSession session = request.getSession(true);
	    ArrayList<Cart> arrCart = new ArrayList<Cart>();
	    ArrayList<Product> arrPro = new ArrayList<Product>();
	    SQLControl control = new SQLControl();
	    System.out.println("hiiiiiiiiiiiiiiiiiiiiii");

		String prodId=request.getParameter("pid");
		String pname=request.getParameter("pname");
		double pprice=Integer.parseInt(request.getParameter("pprice"));
		int pqt=Integer.parseInt(request.getParameter("pqt"));
		Product p1=new Product(prodId, pname, pprice,pqt);
		
		  if (session.getAttribute("cart") == null) {
			  System.out.println("hiiiiiiiiiiiiiiiiiiiiii");

			  arrCart.add(new Cart(prodId,pname, pprice,pqt));
			  System.out.println("hiiiiiiiiiiiiiiiiiiiiii");
			  

		 
	         
		  }
		  session.setAttribute("cart", arrCart);
	        response.sendRedirect("View.jsp");
		  
			  
		  }
		
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
