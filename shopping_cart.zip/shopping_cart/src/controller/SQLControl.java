package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import shopping_cart.model.Product;

public class SQLControl {
	 Connection con;
	    Statement st;
	    ResultSet rs;

	    public SQLControl() {
	    }

	    public void loadDB() {
	        try {
	            con = Dbconnection.getConnection();
	            st = con.createStatement();
	        } catch (Exception ex) {
	            System.out.println("Cant load DB");
	        }

	    }
	    public ArrayList<Product> selectProduct(String id) throws SQLException{
	    	
	    	 ArrayList<Product> pArrList = new ArrayList<>();
	    	 loadDB();
	         String sql = "select * from ProductTBL";
	         try {
	             rs = st.executeQuery(sql);
	             while (rs.next()) {
	                 String pId = rs.getString("ProductID");
	                 String pName = rs.getString("ProductName");
	                 int pPrice = Integer.parseInt(rs.getString("ProductPrice"));
	                 int pqt= Integer.parseInt(rs.getString("pqt"));
	                 
	                 pArrList.add(new Product(pId, pName, pPrice,pqt));
	             }

	         } catch (SQLException ex) {
	             System.out.println("SQL Error");
	         } finally {
	             //disconnect db
	             rs.close();
	             st.close();
	             con.close();
	         }
	         return pArrList;
	     
	    }
	    public ArrayList<Product> selectAllProduct() throws SQLException {
	        ArrayList<Product> pArrList = new ArrayList<>();
	        loadDB();
	        String sql = "select * from Producttlb";
	        try {
	            rs = st.executeQuery(sql);
	            while (rs.next()) {
	                String pId = rs.getString("ProductID");
	                String pName = rs.getString("ProductName");
	                int pPrice = Integer.parseInt(rs.getString("ProductPrice"));
	                int pqt= Integer.parseInt(rs.getString("pqt"));
	                 
	                pArrList.add(new Product(pId, pName, pPrice,pqt));
	            }

	        } catch (SQLException ex) {
	            System.out.println("SQL Error");
	        } finally {
	            //disconnect db
	            rs.close();
	            st.close();
	            con.close();
	        }
	        return pArrList;
	    }

}
